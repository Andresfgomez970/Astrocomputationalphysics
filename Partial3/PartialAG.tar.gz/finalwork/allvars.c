
#include"allvars.h"

// declare, define an assign some varables
SPH *sphPart;
int nPuntos;
double *d;
size_t *p;
double masaTotal;
double masaTotal1;
double masaTotal2;

double densidad = 998.2;

double densidad1 = 997; 
double densidad2 = 1.2; 

double cs = 1493.0;

double cs1 = 1493.0; 
double cs2 = 343; 

double nu = 1.007e-6;
double tiempoTotal = 0.002;
double dt = 0; 
